require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const prisma = require('./lib/prisma');
const { verifyToken } = require('./middleware/auth');
const authRoutes = require('./routes/auth');
const sectorsRoutes = require('./routes/sectors');
const industriesRoutes = require('./routes/industries');
const entitiesRoutes = require('./routes/entities');
const usersRoutes = require('./routes/users');
const assessmentsRoutes = require('./routes/assessments');
const strategicRoutes = require('./routes/strategic');
const reviewsRoutes = require('./routes/reviews');
const versionsRoutes = require('./routes/versions');
const choicesRoutes = require('./routes/choices');
const correctionsRoutes = require('./routes/corrections');
const analysisRoutes = require('./routes/analysis');
const financialRoutes = require('./routes/financial');
const integrationsRoutes = require('./routes/integrations');
const directionsRoutes = require('./routes/directions');
const externalAnalysisRoutes = require('./routes/external-analysis');
const kpiEntriesRoutes = require('./routes/kpi-entries');
const alertsRoutes = require('./routes/alerts');
const auditRoutes = require('./routes/audit');
const dashboardApiRoutes = require('./routes/dashboard-api');
const companiesRoutes = require('./routes/companies');
const toolsRoutes = require('./routes/tools');
const companyAnalysisRoutes = require('./routes/company-analysis');
const syncRoutes = require('./routes/sync');
const alertEngineRoutes = require('./routes/alert-engine');
const causalLinksRoutes = require('./routes/causal-links');
const towsRoutes = require('./routes/tows');
const pathRoutes = require('./routes/path');
const importRoutes = require('./routes/import');
const okrsRoutes = require('./routes/okrs');
const entityTypesRoutes = require('./routes/entity-types');
const priorityMatrixRoutes = require('./routes/priority-matrix');
const inspectorRoutes = require('./routes/system-inspector');
const scenariosRoutes = require('./routes/scenarios');

const app = express();
const PORT = process.env.PORT || 3000;

// Security Middleware
app.use(helmet({
  contentSecurityPolicy: false, // Disabled for development — enable in production
}));

// Rate Limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 500, // limit each IP to 500 requests per windowMs
  message: 'Too many requests from this IP, please try again later.',
  standardHeaders: true,
  legacyHeaders: false,
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // limit each IP to 20 login attempts per windowMs
  message: 'Too many login attempts, please try again later.',
  skipSuccessfulRequests: true,
});

// Apply rate limiting to all routes
app.use('/api/', limiter);

// Basic Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// CORS Configuration
const corsOptions = {
  origin: process.env.NODE_ENV === 'production'
    ? process.env.ALLOWED_ORIGINS?.split(',')
    : ['http://localhost:3000', 'http://127.0.0.1:3000'],
  credentials: true,
  optionsSuccessStatus: 200,
};
app.use(cors(corsOptions));

app.use(express.static(path.join(__dirname, 'public')));

// =========================================
// API Routes — مع حماية الصلاحيات (Phase 8)
// =========================================
const { checkPermission, checkDataEntryPermission, requireRole } = require('./middleware/permission');

// 🔓 Auth — بدون حماية (login/register)
app.use('/api/auth', authLimiter, authRoutes);

// 🔓 Path — مسار عام (لا يحتاج تسجيل دخول)
app.use('/api/path', pathRoutes);

// 📊 Dashboard — كل مستخدم مسجل
app.use('/api/dashboard', dashboardApiRoutes);

// 🔔 Alerts — كل مستخدم مسجل (قراءة)
app.use('/api/alerts', alertsRoutes);

// 📈 KPI Entries — DATA_ENTRY وأعلى
app.use('/api/kpi-entries', kpiEntriesRoutes);

// 🔧 النظام — OWNER/ADMIN فقط
app.use('/api/sectors', sectorsRoutes);
app.use('/api/industries', industriesRoutes);
app.use('/api/entity-types', entityTypesRoutes);
app.use('/api/entities', entitiesRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/companies', companiesRoutes);
app.use('/api/integrations', integrationsRoutes);
app.use('/api/audit', auditRoutes);

// 🎯 الاستراتيجية — EDITOR وأعلى (القراءة متاحة للـ VIEWER)
app.use('/api/assessments', assessmentsRoutes);
app.use('/api/strategic', strategicRoutes);
app.use('/api/strategic/reviews', reviewsRoutes);
app.use('/api/versions', versionsRoutes);
app.use('/api/choices', choicesRoutes);
app.use('/api/corrections', correctionsRoutes);
app.use('/api/analysis', analysisRoutes);
app.use('/api/directions', directionsRoutes);
app.use('/api/external-analysis', externalAnalysisRoutes);
app.use('/api/tools', toolsRoutes);
app.use('/api/company-analysis', companyAnalysisRoutes);
app.use('/api/causal-links', causalLinksRoutes);
app.use('/api/tows', towsRoutes);

// ⚙️ العمليات — EDITOR وأعلى
app.use('/api/financial', financialRoutes);

// 🤖 محرك الذكاء — EDITOR وأعلى
app.use('/api/alert-engine', alertEngineRoutes);
app.use('/api/sync', syncRoutes);

// 📂 الاستيراد — DATA_ENTRY وأعلى  
app.use('/api/import', importRoutes);

// 🎯 OKRs
app.use('/api/okrs', okrsRoutes);

// 🎯 مصفوفة الأولويات — MCDA
app.use('/api/priority-matrix', priorityMatrixRoutes);
app.use('/api/inspector', inspectorRoutes);

// 🔮 محاكاة السيناريوهات
app.use('/api/scenarios', scenariosRoutes);

// Serve import page
app.get('/import', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'import.html'));
});

// Serve strategic tools page
app.get('/strategic-tools', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'strategic-tools.html'));
});

// Serve OKRs page
app.get('/okrs', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'okrs.html'));
});

// Serve Gap Analysis page
app.get('/gap-analysis', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'gap-analysis.html'));
});

// Serve Three Horizons page
app.get('/three-horizons', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'three-horizons.html'));
});

// Serve OGSM page
app.get('/ogsm', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'ogsm.html'));
});

// Serve Simulation Lab page
app.get('/simulation-lab', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'simulation-lab.html'));
});

// Serve login page
app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Serve signup page
app.get('/signup', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'signup.html'));
});

// Serve Super Admin Dashboard (برج المراقبة)
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Serve dashboard/welcome page (protected by frontend)
app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Serve strategic pipeline page
app.get('/tools', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'tools.html'));
});

// Serve tool detail page
app.get('/tool', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'tool-detail.html'));
});

// Serve sectors page
app.get('/sectors', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'sectors.html'));
});

// Serve industries page
app.get('/industries', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'industries.html'));
});

// Serve entities page
app.get('/entities', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'entities.html'));
});

// Serve users page
app.get('/users', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'users.html'));
});

// Serve assessments page
app.get('/assessments', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'assessments.html'));
});

// Serve KPIs page
app.get('/kpis', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'kpis.html'));
});

// Serve settings page
app.get('/settings', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'settings.html'));
});

// Serve settings-data page
app.get('/settings-data', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'settings-data.html'));
});

// Serve onboarding wizard
app.get('/onboarding', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'onboarding.html'));
});

// Serve versions page
app.get('/versions', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'versions.html'));
});

// Serve choices page
app.get('/choices', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'choices.html'));
});

// Serve corrections page
app.get('/corrections', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'corrections.html'));
});

// Serve analysis page
app.get('/analysis', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'analysis.html'));
});

// Serve financial page
app.get('/financial', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'financial.html'));
});

// Serve integrations page
app.get('/integrations', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'integrations.html'));
});

// Serve directions page
app.get('/directions', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'directions.html'));
});

// Serve objectives page
app.get('/objectives', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'objectives.html'));
});

// Serve initiatives page
app.get('/initiatives', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'initiatives.html'));
});

// Serve reviews page
app.get('/reviews', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'reviews.html'));
});

// Redirect alerts to intelligence page (alerts are shown there)
app.get('/alerts', (req, res) => {
  res.redirect('/intelligence');
});

// Serve TOWS Matrix page
app.get('/tows', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'tows.html'));
});

// Serve Strategy Map / Causal Links page
app.get('/strategy-map', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'strategy-map.html'));
});

// Serve KPI entries page
app.get('/kpi-entries', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'kpi-entries.html'));
});

// Serve Priority Matrix page
app.get('/priority-matrix', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'priority-matrix.html'));
});
app.get('/inspector', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'inspector.html'));
});

// Serve Intelligence Dashboard
app.get('/intelligence', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'intelligence.html'));
});

// Serve Path 1 journey
app.get('/path1', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'path1.html'));
});

// Landing page (public homepage)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'landing.html'));
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Error:', err);

  // Don't leak error details in production
  const message = process.env.NODE_ENV === 'production'
    ? 'Internal server error'
    : err.message;

  res.status(err.status || 500).json({
    success: false,
    message,
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: 'Not found' });
});

// Start the server
app.listen(PORT, () => {
  console.log(`🚀 Stratix server is running on http://localhost:${PORT}`);
  console.log(`📝 Login at http://localhost:${PORT}/login`);

  // ============ AUTO-SCAN SCHEDULER ============
  // Run alert engine scan every 2 hours
  const SCAN_INTERVAL = 2 * 60 * 60 * 1000; // 2 hours

  async function autoScan() {
    try {
      console.log('🔍 [Auto-Scan] Starting scheduled alert engine scan...');
      const entities = await prisma.entity.findMany();
      let totalAlerts = 0;

      for (const entity of entities) {
        const activeVersion = await prisma.strategyVersion.findFirst({
          where: { entityId: entity.id, isActive: true }
        });
        if (!activeVersion) continue;

        // Check KPIs
        const kpis = await prisma.kPI.findMany({
          where: { versionId: activeVersion.id },
          select: { id: true, name: true, actual: true, target: true, warningThreshold: true, criticalThreshold: true, objectiveId: true }
        });

        for (const kpi of kpis) {
          if (!kpi.target || kpi.target === 0 || kpi.actual == null) continue;
          const ratio = kpi.actual / kpi.target;
          if (ratio >= 0.9) continue;

          const existing = await prisma.strategicAlert.findFirst({
            where: { entityId: entity.id, referenceId: kpi.id, referenceType: 'KPI', isDismissed: false, createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) } }
          });
          if (existing) continue;

          const critThresh = kpi.criticalThreshold || 0.5;
          if (ratio <= critThresh) {
            await prisma.strategicAlert.create({ data: { entityId: entity.id, type: 'KPI_CRITICAL', severity: 'CRITICAL', title: `⛔ مؤشر "${kpi.name}" في وضع حرج`, message: `الأداء (${(ratio * 100).toFixed(1)}%) — ${kpi.actual} من ${kpi.target}`, referenceId: kpi.id, referenceType: 'KPI' } });
            totalAlerts++;
          }
        }
      }

      console.log(`✅ [Auto-Scan] Complete — ${totalAlerts} new alerts generated`);
    } catch (err) {
      console.error('❌ [Auto-Scan] Error:', err.message);
    }
  }

  // Run first scan after 30 seconds (let server warm up)
  setTimeout(autoScan, 30000);
  // Then every 2 hours
  setInterval(autoScan, SCAN_INTERVAL);
});
